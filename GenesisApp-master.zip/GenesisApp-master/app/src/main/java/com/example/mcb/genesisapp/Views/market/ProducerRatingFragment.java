package com.example.mcb.genesisapp.Views.market;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by asfandyarsheikh on 2/15/18.
 */

public class ProducerRatingFragment extends Fragment {
}
