/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Features;

/**
 * Gives value to a Token. I.e. a service, commodity etc.
 * @author mcb
 */
public interface IUnderlying extends IFeature{
    
}
